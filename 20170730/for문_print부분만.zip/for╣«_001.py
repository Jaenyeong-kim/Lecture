a = ["one","two","three","four","five","six","seven","eight","nine","ten"]
for i in a:
    print(i)
    f.write(i+"\n")
