a = ["one","two","three","four","five","six",
     "seven","eight","nine","ten"]
b = ["first","secend","third","fourth","fifth",
     "sixth","seventh","eighth","ninth","tenth"]
for i in range(10):
    print(a[i]  ,  b[i])
