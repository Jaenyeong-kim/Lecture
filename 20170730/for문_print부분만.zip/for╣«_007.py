a = ["one","two","three","four","five","six","seven","eight","nine","ten"]
b = ["first","secend","third","fourth","fifth","sixth","seventh","eighth","ninth","tenth"]
c = ["1","2","3","4","5","6","7","8","9","10"]
d = ["aaa","bbb","ccc","ddd","eee","fff","ggg","hhh","iii","kkk"]

for i in range(10):
    f.write(a[i]+"\t"+b[i]+"\t"+c[i]+"\t"+d[i]+"\n")
